/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.uajs.listas.ruta;

import java.util.LinkedList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.ArrayList;

public class RutaCircularLib {

    private final LinkedList<Parada> cola = new LinkedList<>();

    public void agregar(Parada parada) {
        cola.addLast(parada);
    }

    public Parada siguiente() {
        if (cola.isEmpty()) {
            return null;
        }

        Parada parada = cola.removeFirst();
        cola.addLast(parada);

        return cola.getFirst();
    }

    public Parada anterior() {
        if (cola.isEmpty()) {
            return null;
        }

        Parada parada = cola.removeLast();
        cola.addFirst(parada);

        return cola.getFirst();
    }

    public Parada saltarNo(int n) {
        if (cola.isEmpty()) {
            return null;
        }

        Collections.rotate(cola, -n);
        return cola.getFirst();
    }

    public Parada eliminarActual() {
        if (cola.isEmpty()) {
            return null;
        }

        return cola.removeFirst();
    }

    public int tiempoTotal() {
        int total = 0;

        for (Parada parada : cola) {
            total += parada.minutos();
        }

        return total;
    }

    public List<String> nombresDesdeActual() {
        List<String> nombres = new ArrayList<>();

        for (Parada parada : cola) {
            nombres.add(parada.nombre());
        }

        return nombres;
    }

    public Parada actual() {
        return cola.peekFirst();
    }

    public int tamanio() {
        return cola.size();
    }

    public boolean irA(String nombre) {
        ListIterator<Parada> iterador = cola.listIterator();

        while (iterador.hasNext()) {
            Parada parada = iterador.next();

            if (parada.nombre().equalsIgnoreCase(nombre)) {
                Collections.rotate(cola, -cola.indexOf(parada));
                return true;
            }
        }

        return false;
    }

    public void reordenar(long semilla) {
        Collections.shuffle(cola, new java.util.Random(semilla));
    }
}