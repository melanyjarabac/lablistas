/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.uajs.listas.ruta;

/**
 *
 * @author Lenovo
 */
public interface RutaCircular {
    void agregar(Parada parada);
    Parada actual();
    Parada siguiente();
    Parada anterior();
    void saltar(int n);
    Parada eliminarActual();
    int tiempoTotal();
}
