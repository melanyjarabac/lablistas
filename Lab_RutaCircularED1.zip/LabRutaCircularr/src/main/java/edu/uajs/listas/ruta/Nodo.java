/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.uajs.listas.ruta;

/**
 *
 * @author Lenovo
 */
public class Nodo {
    Parada dato;
    Nodo siguiente;
    Nodo anterior;

    public Nodo(Parada dato) {
        this.dato = dato;
    }
}
