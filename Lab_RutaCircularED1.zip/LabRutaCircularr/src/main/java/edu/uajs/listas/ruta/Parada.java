/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.uajs.listas.ruta;

/**
 *
 * @author Lenovo
 */
public record Parada (String nombre, String sector, int minutos) {
    
}
    