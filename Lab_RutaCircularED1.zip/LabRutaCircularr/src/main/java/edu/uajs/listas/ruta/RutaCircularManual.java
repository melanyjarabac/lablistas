/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.List;

public class RutaCircularManual {

    private Nodo primero;
    private Nodo actual;
    private int tamanio;

    public RutaCircularManual() {
        primero = null;
        actual = null;
        tamanio = 0;
    }

    public void agregar(Parada parada) {
        Nodo nuevo = new Nodo(parada);

        if (primero == null) {
            primero = nuevo;
            actual = nuevo;
            nuevo.siguiente = nuevo;
            nuevo.anterior = nuevo;
        } else {
            Nodo ultimo = primero.anterior;

            nuevo.siguiente = primero;
            nuevo.anterior = ultimo;
            ultimo.siguiente = nuevo;
            primero.anterior = nuevo;
        }

        tamanio++;
    }

    public Parada siguiente() {
        if (actual == null) {
            return null;
        }

        actual = actual.siguiente;
        return actual.dato;
    }

    public Parada anterior() {
        if (actual == null) {
            return null;
        }

        actual = actual.anterior;
        return actual.dato;
    }

    public Parada saltarNo(int n) {
        if (actual == null) {
            return null;
        }

        n %= tamanio;

        if (n > 0) {
            for (int i = 0; i < n; i++) {
                actual = actual.siguiente;
            }
        } else {
            for (int i = 0; i > n; i--) {
                actual = actual.anterior;
            }
        }

        return actual.dato;
    }

    public Parada eliminarActual() {
        if (actual == null) {
            return null;
        }

        Parada eliminada = actual.dato;

        if (tamanio == 1) {
            primero = null;
            actual = null;
            tamanio = 0;
            return eliminada;
        }

        Nodo previo = actual.anterior;
        Nodo proximo = actual.siguiente;

        previo.siguiente = proximo;
        proximo.anterior = previo;

        if (actual == primero) {
            primero = proximo;
        }

        actual = proximo;
        tamanio--;

        return eliminada;
    }

    public int tiempoTotal() {
        if (primero == null) {
            return 0;
        }

        int total = 0;
        Nodo aux = primero;

        do {
            total += aux.dato.minutos();
            aux = aux.siguiente;
        } while (aux != primero);

        return total;
    }

    public List<String> nombresDesdeActual() {
        List<String> nombres = new ArrayList<>();

        if (actual == null) {
            return nombres;
        }

        Nodo aux = actual;

        do {
            nombres.add(aux.dato.nombre());
            aux = aux.siguiente;
        } while (aux != actual);

        return nombres;
    }

    public int tamanio() {
        return tamanio;
    }

    public Parada actual() {
        return actual == null ? null : actual.dato;
    }
}
        
        