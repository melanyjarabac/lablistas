/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package edu.uajs.listas.ruta;

/**
 *
 * @author Lenovo
 */
public class LabRutaCircularr {

    public static void main(String[] args) {

        RutaCircularManual ruta = new RutaCircularManual();

        ruta.agregar(new Parada("Parada A", "Norte", 10));
        ruta.agregar(new Parada("Parada B", "Centro", 15));
        ruta.agregar(new Parada("Parada C", "Sur", 20));

        System.out.println("Ruta inicial:");
        System.out.println(ruta.nombresDesdeActual());

        System.out.println("Siguiente:");
        System.out.println(ruta.siguiente());

        System.out.println("Anterior:");
        System.out.println(ruta.anterior());

        System.out.println("Saltar dos paradas:");
        System.out.println(ruta.saltarNo(2));

        System.out.println("Tiempo total:");
        System.out.println(ruta.tiempoTotal());

        System.out.println("Eliminar parada actual:");
        System.out.println(ruta.eliminarActual());

        System.out.println("Ruta final:");
        System.out.println(ruta.nombresDesdeActual());
    }
}